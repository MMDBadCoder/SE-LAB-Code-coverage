package org.json.simple;

import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public class ObjectTest {

    @Test
    public void keyValueTest() {
        String actual = JSONObject.toString("key", "value");
        Assert.assertEquals(actual, "\"key\":\"value\"");
    }

    @Test
    public void toStringTest() throws IOException, ParseException {
        Map<String, String> map = new HashMap<String, String>();
        map.put("First Name", "Mohammad");
        map.put("Last name", "heydari");
        JSONObject jsonObject = new JSONObject(map);
        String expectedJson = "{\"First Name\":\"Mohammad\",\"Last name\":\"heydari\"}";
        Assert.assertEquals(expectedJson, jsonObject.toJSONString());
        Assert.assertEquals(expectedJson, jsonObject.toString());
        StringWriter writer = new StringWriter();
        jsonObject.writeJSONString(writer);
        writer.flush();
        Assert.assertEquals(writer.toString(), expectedJson);
        Map reconvertedMap = (Map) JSONValue.parseWithException(expectedJson);
        Assert.assertEquals(map, reconvertedMap);
        StringReader reader = new StringReader(expectedJson);
        reconvertedMap = (Map) JSONValue.parseWithException(reader);
        Assert.assertEquals(map, reconvertedMap);
    }

    @Test
    public void writeJSONStringTest() throws IOException {
        writeJSONStringTest(2.45, "2.45");
        writeJSONStringTest((float) 2.45, "2.45");
        writeJSONStringTest(2, "2");
        writeJSONStringTest((byte) 2, "2");
        writeJSONStringTest((short) 2, "2");
        writeJSONStringTest((long) 2, "2");
    }

    public void writeJSONStringTest(Object value, String expectedString) throws IOException {
        StringWriter writer = new StringWriter();
        JSONValue.writeJSONString(value, writer);
        writer.flush();
        Assert.assertEquals(writer.toString(), expectedString);
    }
}
