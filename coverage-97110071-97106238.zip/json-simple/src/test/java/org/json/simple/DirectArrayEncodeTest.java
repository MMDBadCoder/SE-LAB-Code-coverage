package org.json.simple;

import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;

public class DirectArrayEncodeTest {

    @Test
    public void bytesToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new byte[]{1, 2, 3}, "[1,2,3]");
    }

    @Test
    public void shortsToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new short[]{1, 2, 3}, "[1,2,3]");
    }

    @Test
    public void floatsToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new float[]{(float) 1.2, (float) 2.8, (float) 3},
                "[1.2,2.8,3.0]");
    }

    @Test
    public void doublesToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new double[]{1.2, 2.8, 3.13},
                "[1.2,2.8,3.13]");
    }

    @Test
    public void intsToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new int[]{1, 2, 3},
                "[1,2,3]");
    }

    @Test
    public void longsToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new long[]{1, 2, 3},
                "[1,2,3]");
    }

    @Test
    public void objectsToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new Object[]{1, 2, 3},
                "[1,2,3]");
    }

    @Test
    public void booleansToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new boolean[]{true, false},
                "[true,false]");
    }

    @Test
    public void charsToJsonTest() throws Exception {
        new ArrayEncoderTester().test(new char[]{'c', 'h'},
                "[\"c\",\"h\"]");
    }

    @Test
    public void toStringTest() throws IOException {
        JSONArray jsonArray = new JSONArray(Collections.singleton(1));
        Assert.assertEquals(jsonArray.toString(), "[1]");
        StringWriter stringWriter = new StringWriter();
        jsonArray.writeJSONString(stringWriter);
        stringWriter.flush();
        Assert.assertEquals(stringWriter.toString(), "[1]");
    }

    public static class ArrayEncoderTester {
        public void test(Object numbers, String expectedJsonString) throws Exception {
            JSONArray jsonArray = new JSONArray();
            StringWriter writer = new StringWriter();

            Method writeJSONStringMethod = JSONArray.class.getMethod("writeJSONString",
                    numbers.getClass(), Writer.class);
            Method toJSONStringMethod = JSONArray.class.getMethod("toJSONString", numbers.getClass());

            writeJSONStringMethod.invoke(jsonArray, numbers, writer);
            String jsonConvertedText = (String) toJSONStringMethod.invoke(jsonArray, numbers);

            writer.flush();
            Assert.assertEquals(expectedJsonString, writer.toString());
            Assert.assertEquals(writer.toString(), jsonConvertedText);

            JSONArray array = (JSONArray) JSONValue.parseWithException(writer.toString());

            for (int i = 0; i < Array.getLength(numbers); i++) {
                Assert.assertEquals(array.get(i).toString(), Array.get(numbers, i).toString());
            }

            writer = new StringWriter();
            JSONValue.writeJSONString(numbers, writer);
            Assert.assertEquals(writer.toString(), expectedJsonString);

            // this line is for testing null value, it shouldn't throw any exception
            writeJSONStringMethod.invoke(jsonArray, null, writer);
        }
    }
}
