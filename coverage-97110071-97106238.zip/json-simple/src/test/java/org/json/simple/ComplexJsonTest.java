package org.json.simple;

import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Map;

public class ComplexJsonTest {

    @Test
    public void fromFileTest() throws IOException, ParseException {
        BufferedReader bufferedReader = new BufferedReader(
                new FileReader("src/test/java/org/json/simple/sample.json"));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        String ls = System.getProperty("line.separator");
        while ((line = bufferedReader.readLine()) != null) {
            stringBuilder.append(line);
            stringBuilder.append(ls);
        }
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        bufferedReader.close();

        String content = stringBuilder.toString();

        Map map = (Map) JSONValue.parseWithException(content);
        checkCorrectnessOfMap(map);

        map = (Map) JSONValue.parse(content);
        checkCorrectnessOfMap(map);

        StringReader reader = new StringReader(content);
        map = (Map) JSONValue.parse(reader);
        checkCorrectnessOfMap(map);
    }

    public void checkCorrectnessOfMap(Map map) {
        Assert.assertEquals(map.get("First Name"), "Mohammad");
        Assert.assertEquals(map.get("Last Name"), "Heydari");
        Assert.assertEquals(map.get("Age"), (long) 22);
        ArrayList<Object> friends = (ArrayList<Object>) map.get("Friends");
        Assert.assertEquals(1, friends.size());
        Map friend = (Map) friends.get(0);
        Assert.assertEquals(friend.get("First Name"), "Mohammad Hossein");
        Assert.assertEquals(friend.get("Last Name"), "Gheysarieh");
        Assert.assertEquals(friend.get("Age"), (long) 23);
    }
}
