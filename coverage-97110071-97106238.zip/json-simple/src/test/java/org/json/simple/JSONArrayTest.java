package org.json.simple;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.parser.ParseException;
import org.junit.Test;

public class JSONArrayTest {

    @Test
    public void testDecodeIntegerList() throws Exception {
        String jsonText = "[1, 0, 3, 10]";
        ArrayList<Object> expectedValues = new ArrayList<Object>();
        expectedValues.add(1);
        expectedValues.add(0);
        expectedValues.add(3);
        expectedValues.add(10);
        testListDecode(jsonText, expectedValues);
    }

    @Test
    public void testDecodeStringList() throws Exception {
        String jsonText = "[\"mmd\", \"1\", \"97110071\", \"sharif\"]";
        ArrayList<Object> expectedValues = new ArrayList<Object>();
        expectedValues.add("mmd");
        expectedValues.add("1");
        expectedValues.add("97110071");
        expectedValues.add("sharif");
        testListDecode(jsonText, expectedValues);
    }

    @Test
    public void testJSONStringArrayCollection() {
        final ArrayList<String> testList = new ArrayList<String>();
        testList.add("First item");
        testList.add("Second item");
        final JSONArray jsonArray = new JSONArray(testList);

        assertEquals("[\"First item\",\"Second item\"]", jsonArray.toJSONString());
    }

    @Test
    public void testJSONIntegerArrayCollection() {
        final ArrayList<Integer> testList = new ArrayList<Integer>();
        testList.add(10);
        testList.add(0);
        testList.add(5);
        final JSONArray jsonArray = new JSONArray(testList);

        assertEquals("[10,0,5]", jsonArray.toJSONString());
    }


    public void testListDecode(String jsonText, List<Object> expectedValues) throws ParseException {
        Object obj = JSONValue.parseWithException(jsonText);
        JSONArray array = (JSONArray) obj;
        assertEquals(array.size(), expectedValues.size());
        for (int i = 0; i < array.size(); i++) {
            assertEquals(array.get(i).toString(), expectedValues.get(i).toString());
        }
    }
}
