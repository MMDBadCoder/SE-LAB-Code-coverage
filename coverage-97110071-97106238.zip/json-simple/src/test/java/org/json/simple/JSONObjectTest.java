package org.json.simple;

import org.json.simple.parser.ParseException;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class JSONObjectTest {

    @Test
    public void personalDetailEncodeTest() throws ParseException {
        Map<Object, Object> map = new HashMap<Object, Object>();
        map.put("First Name", "Mohammad");
        map.put("Last Name", "Heydari");
        map.put("Student Id", "97110071");
        testMapDecode(JSONObject.toJSONString(map), map);
    }

    @Test
    public void squareNumberTest() throws ParseException {
        Map<Object, Object> map = new HashMap<Object, Object>();
        for (int i = 0; i < 5; i++) {
            map.put(String.valueOf(i), String.valueOf(i * i));
        }
        testMapDecode(JSONObject.toJSONString(map), map);
    }

    @Test
    public void personalDetailDecodeTest() throws ParseException {
        String jsonText = "{\"Student Id\":\"97110071\",\"First Name\":\"Mohammad\",\"Last Name\":\"Heydari\"}";
        Object map = JSONValue.parseWithException(jsonText);
        String reConvertedText = new JSONObject().toJSONString((Map) map);
        assertEquals(jsonText, reConvertedText);
    }

    public void testMapDecode(String jsonText, Map<Object, Object> expectedMap) throws ParseException {
        Object obj = JSONValue.parseWithException(jsonText);
        JSONObject actualMap = (JSONObject) obj;
        assertEquals(actualMap.size(), expectedMap.size());
        for (Object expectedKey : expectedMap.keySet()) {
            assertEquals(actualMap.get(expectedKey).toString(), expectedMap.get(expectedKey));
        }
    }

}
